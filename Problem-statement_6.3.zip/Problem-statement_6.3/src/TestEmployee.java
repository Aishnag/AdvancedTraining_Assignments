import java.util.Collections;

import java.util.LinkedList;
import java.util.Scanner;

public class TestEmployee {
	
	static LinkedList<Employee> al=new LinkedList<Employee>();
	static Scanner input = new Scanner(System.in);
	public static void main(String[] args) {
		
		
		Employee e1 = new Employee(1,"Raj","Atal Nagar");
		
		
		
		System.out.println(e1.getEmployeeNo());
		System.out.println(e1.getEmployeeName());
		System.out.println(e1.getEmployeeAddress());
		
		
		TestEmployee ref = new TestEmployee();
		ref.addInput();
		ref.display();

	}
	
	
	public void addInput() {
		
		System.out.println("Number of Entries: ");
		int n = input.nextInt();
		input.nextLine();
		for(int i=1;i<=n;i++) {
			
			System.out.println("Enter Id: ");
			int id = input.nextInt();
			input.nextLine();
			
			System.out.println("Enter Employeename: ");
			String name = input.next();
			
			System.out.println("Enter EmployeeAddress: ");
			String address = input.next();
			
			Employee i1 = new Employee(id,name,address);
			
			al.add(i1);
			
		}
	}

	
	public void display() {
		
		System.out.println("In ascending order: ");
		 for(Employee d:al) {
			 System.out.println(d.getEmployeeNo()+" "+d.getEmployeeName()+" "+d.getEmployeeAddress());
		 }
		  
		System.out.println("In decending order: ");
		Collections.reverse(al);
		 for(Employee d:al) {
			 System.out.println(d.getEmployeeNo()+" "+d.getEmployeeName()+" "+d.getEmployeeAddress());
		 }
		
		 
		  
		 
	}
}
