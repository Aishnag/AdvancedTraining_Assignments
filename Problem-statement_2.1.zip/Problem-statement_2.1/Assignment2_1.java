package com.assignment;

import java.util.Scanner;

public class Assignment2_1{
	
	public static void main(String[] args) {
		 String[] name = {"John Doe", "Mary Jane", "Peter Pan"};
		    
     
   	 for ( int i = 0; i < name.length; i++ )
   	 {
   	    System.out.println( name[i] );
   	    System.out.println(name[i].toUpperCase());
	}
   	 palindrome();
   	 
	}
	
	public static void  palindrome() {
		 String original, reverse = ""; // Objects of String class  
	      Scanner in = new Scanner(System.in);   
	      System.out.println("Enter a string to check if it is a palindrome");  
	      original = in.nextLine();   
	      int length = original.length();   
	      for ( int i = length - 1; i >= 0; i-- )  
	         reverse = reverse + original.charAt(i);  
	      if (original.equals(reverse))  
	         System.out.println("Entered string is a palindrome.");  
	      else  
	         System.out.println("Entered string isn't a palindrome.");   
	   }  
	}
